package com.handysparksoft.shakelamp;

import android.app.Service;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;

public class ShakeService extends Service {

    private static final String LOG_TAG = ShakeLamp.class.getName();
    public static  Boolean running = false;
    private static ShakeLamp shakeLampInstance;
    //Binder
    private final IBinder binder = new ShakeBinder();
    private ScreenStateReceiver screenStateReceiver;

    public ShakeService() {
    }

    public static Boolean getRunning() {
        return running;
    }

    public static void setRunning(Boolean running) {
        ShakeService.running = running;
    }

    public static ShakeLamp getShakeLampInstance() {
        if (shakeLampInstance == null) {
            shakeLampInstance = new ShakeLamp();
        }
        return shakeLampInstance;
    }

    @Override
    public IBinder onBind(Intent intent) {
        Log.w(LOG_TAG, "Service binded with " + intent != null ? intent.getClass().toString() : "");
        return binder;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.w(LOG_TAG, "Service started");
        setRunning(true);
        getShakeLampInstance().init(getApplicationContext());
        registerScreenReceivers();

        return START_STICKY;
    }

    public void stopShakeService() {
        stopSelf();
        setRunning(false);
        Log.w(LOG_TAG, "Service stopped");
    }


    //Getters & Setters

    @Override
    public void onCreate() {
        setRunning(true);
        super.onCreate();
    }

    @Override
    public void onDestroy() {
        Log.w(LOG_TAG, "Service destroyed");
        unregisterScreenReceivers();
        setRunning(false);
        super.onDestroy();
    }

    private void registerScreenReceivers() {
        screenStateReceiver = new ScreenStateReceiver();
        screenStateReceiver.setShakeLamp(getShakeLampInstance());
        IntentFilter screenStateFilter = new IntentFilter();
        screenStateFilter.addAction(Intent.ACTION_SCREEN_ON);
        screenStateFilter.addAction(Intent.ACTION_SCREEN_OFF);
        registerReceiver(screenStateReceiver, screenStateFilter);
    }

    private void unregisterScreenReceivers() {
        if (screenStateReceiver != null) {
            unregisterReceiver(screenStateReceiver);
        }
    }

    public class ShakeBinder extends Binder {
        ShakeService getService() {
            return ShakeService.this;
        }
    }


}

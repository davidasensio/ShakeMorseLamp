package com.handysparksoft.shakelamp;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.preference.CheckBoxPreference;
import android.preference.ListPreference;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.preference.PreferenceCategory;
import android.preference.PreferenceFragment;
import android.preference.PreferenceManager;
import android.preference.SwitchPreference;

import java.util.List;

/**
 * A {@link PreferenceActivity} that presents a set of application settings. On
 * handset devices, settings are presented as a single list. On tablets,
 * settings are split by category, with category headers shown to the left of
 * the list of settings.
 * <p/>
 * See <a href="http://developer.android.com/design/patterns/settings.html">
 * Android Design: Settings</a> for design guidelines and the <a
 * href="http://developer.android.com/guide/topics/ui/settings.html">Settings
 * API Guide</a> for more information on developing a Settings UI.
 */
public class SettingsActivity extends PreferenceActivity {
    /**
     * Determines whether to always show the simplified settings UI, where
     * settings are presented in a single list. When false, settings are shown
     * as a master/detail two-pane view on tablets. When true, a single pane is
     * shown on tablets.
     */
    private static final boolean ALWAYS_SIMPLE_PREFS = false;



    private static Context context;
    private static SharedPreferences prefs;
    /**
     * A preference value change listener that updates the preference's summary
     * to reflect its new value.
     */
    private static Preference.OnPreferenceChangeListener sBindPreferenceSummaryToValueListener = new Preference.OnPreferenceChangeListener() {
        @Override
        public boolean onPreferenceChange(Preference preference, Object value) {
            String stringValue = value.toString();

            if (preference instanceof ListPreference) {
                // For list preferences, look up the correct display value in
                // the preference's 'entries' list.
                ListPreference listPreference = (ListPreference) preference;
                int index = listPreference.findIndexOfValue(stringValue);

                // Set the summary to reflect the new value.
                preference.setSummary(
                        index >= 0
                                ? listPreference.getEntries()[index]
                                : null);

            } else {
                String summary = stringValue;
                if (preference.getKey().equals(Constants.PREF_BATTERY_CARE)) {
                    summary = Boolean.valueOf(stringValue) ? context.getString(R.string.pref_battery_care_description_on) : context.getString(R.string.pref_battery_care_description_off);
                    preference.setSummary(summary);
                } else if(preference.getKey().equals(Constants.PREF_SERVICE_ACTIVATED)) {
                    summary = Boolean.valueOf(stringValue) ? context.getString(R.string.pref_service_activated_on) : context.getString(R.string.pref_service_activated_off);
                    preference.setSummary(summary);
                }else if (preference.getKey().equals(Constants.PREF_VIBRATE)) {
                    //Nothing
                } else {
                    //Set rest of summaries
                    preference.setSummary(summary);
                }
            }

            //Save preferences and apply changes
            if (preference instanceof SwitchPreference || preference instanceof CheckBoxPreference) {
                prefs.edit().putBoolean(preference.getKey(), Boolean.valueOf(stringValue)).commit();
            } else {
                prefs.edit().putString(preference.getKey(),stringValue).commit();
            }

            return true;
        }
    };

    /**
     * Helper method to determine if the device has an extra-large screen. For
     * example, 10" tablets are extra-large.
     */
    private static boolean isXLargeTablet(Context context) {
        return (context.getResources().getConfiguration().screenLayout
                & Configuration.SCREENLAYOUT_SIZE_MASK) >= Configuration.SCREENLAYOUT_SIZE_XLARGE;
    }

    /**
     * Determines whether the simplified settings UI should be shown. This is
     * true if this is forced via {@link #ALWAYS_SIMPLE_PREFS}, or the device
     * doesn't have newer APIs like {@link PreferenceFragment}, or the device
     * doesn't have an extra-large screen. In these cases, a single-pane
     * "simplified" settings UI should be shown.
     */
    private static boolean isSimplePreferences(Context context) {
        return ALWAYS_SIMPLE_PREFS
                || Build.VERSION.SDK_INT < Build.VERSION_CODES.HONEYCOMB
                || !isXLargeTablet(context);
    }

    /**
     * Binds a preference's summary to its value. More specifically, when the
     * preference's value is changed, its summary (line of text below the
     * preference title) is updated to reflect the value. The summary is also
     * immediately updated upon calling this method. The exact display format is
     * dependent on the type of preference.
     *
     * @see #sBindPreferenceSummaryToValueListener
     */
    private static void bindPreferenceSummaryToValue(Preference preference) {
        // Set the listener to watch for value changes.
        preference.setOnPreferenceChangeListener(sBindPreferenceSummaryToValueListener);

        // Trigger the listener immediately with the preference's current value.
        if (preference instanceof SwitchPreference || preference instanceof CheckBoxPreference) {
            sBindPreferenceSummaryToValueListener.onPreferenceChange(preference, PreferenceManager.getDefaultSharedPreferences(preference.getContext()).getBoolean(preference.getKey(), true));
        }else {
            sBindPreferenceSummaryToValueListener.onPreferenceChange(preference, PreferenceManager.getDefaultSharedPreferences(preference.getContext()).getString(preference.getKey(), ""));

        }
    }

    public static SharedPreferences getPrefs(Context context) {
        PreferenceManager.setDefaultValues(context, R.xml.pref_general, false);
        PreferenceManager.setDefaultValues(context, R.xml.pref_user, false);

        prefs = context.getSharedPreferences("SHARED_PREFS", MODE_PRIVATE);


        return prefs;
    }

    public static PreferencesDto getShakeLampPreferences(Context context) {
        SharedPreferences sp =  getPrefs(context);
        PreferencesDto preferencesDto = new PreferencesDto();

        preferencesDto.setServiceActivated(sp.getBoolean(Constants.PREF_SERVICE_ACTIVATED, true));
        preferencesDto.setBatterySaver(sp.getBoolean(Constants.PREF_BATTERY_CARE, true));
        preferencesDto.setVibrate(sp.getBoolean(Constants.PREF_VIBRATE, true));
        preferencesDto.setLightAutoOffMinutes(Integer.valueOf(sp.getString(Constants.PREF_LIGHT_AUTO_OFF, String.valueOf(preferencesDto.getLightAutoOffMinutes()))));
        preferencesDto.setSensibilityLevelAsInteger(Integer.valueOf(sp.getString(Constants.PREF_SENSIBILITY, "3")));

        return preferencesDto;
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);

        this.context = this;
        setupSimplePreferencesScreen();
    }

    /**
     * Shows the simplified settings UI if the device configuration if the
     * device configuration dictates that a simplified, single-pane UI should be
     * shown.
     */
    private void setupSimplePreferencesScreen() {
        if (!isSimplePreferences(this)) {
            return;
        }

        // In the simplified UI, fragments are not used at all and we instead
        // use the older PreferenceActivity APIs.

        // Add 'general' preferences.
        addPreferencesFromResource(R.xml.pref_general);

        // Add 'notifications' preferences, and a corresponding header.
        PreferenceCategory fakeHeader = new PreferenceCategory(this);
        fakeHeader.setTitle(R.string.pref_header_user);
        getPreferenceScreen().addPreference(fakeHeader);
        addPreferencesFromResource(R.xml.pref_user);

        // Add 'data and sync' preferences, and a corresponding header.
        fakeHeader = new PreferenceCategory(this);
        fakeHeader.setTitle(R.string.pref_header_about);
        getPreferenceScreen().addPreference(fakeHeader);
        addPreferencesFromResource(R.xml.pref_about);

        // Bind the summaries of EditText/List/Dialog/Ringtone preferences to
        // their values. When their values change, their summaries are updated
        // to reflect the new value, per the Android Design guidelines.

        bindPreferenceSummaryToValue(findPreference(Constants.PREF_SERVICE_ACTIVATED));
        bindPreferenceSummaryToValue(findPreference(Constants.PREF_BATTERY_CARE));
        bindPreferenceSummaryToValue(findPreference(Constants.PREF_LIGHT_AUTO_OFF));
        bindPreferenceSummaryToValue(findPreference(Constants.PREF_VIBRATE));
        bindPreferenceSummaryToValue(findPreference(Constants.PREF_SENSIBILITY));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean onIsMultiPane() {
        return isXLargeTablet(this) && !isSimplePreferences(this);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    public void onBuildHeaders(List<Header> target) {
        if (!isSimplePreferences(this)) {
            loadHeadersFromResource(R.xml.pref_headers, target);
        }
    }

    /**
     * This fragment shows general preferences only. It is used when the
     * activity is showing a two-pane settings UI.
     */
    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    public static class GeneralPreferenceFragment extends PreferenceFragment {
        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            addPreferencesFromResource(R.xml.pref_general);

            // Bind the summaries of EditText/List/Dialog/Ringtone preferences
            // to their values. When their values change, their summaries are
            // updated to reflect the new value, per the Android Design
            // guidelines.

            bindPreferenceSummaryToValue(findPreference("pref_light_auto_off_titles"));
            bindPreferenceSummaryToValue(findPreference("pref_light_auto_off_values"));
        }
    }

    //Getters & Setters

    /**
     * This fragment shows notification preferences only. It is used when the
     * activity is showing a two-pane settings UI.
     */
    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    public static class NotificationPreferenceFragment extends PreferenceFragment {
        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            addPreferencesFromResource(R.xml.pref_user);

            // Bind the summaries of EditText/List/Dialog/Ringtone preferences
            // to their values. When their values change, their summaries are
            // updated to reflect the new value, per the Android Design
            // guidelines.
            //bindPreferenceSummaryToValue(findPreference("notifications_new_message_ringtone"));
        }
    }

    /**
     * This fragment shows data and sync preferences only. It is used when the
     * activity is showing a two-pane settings UI.
     */
    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    public static class AboutPreferenceFragment extends PreferenceFragment {
        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            addPreferencesFromResource(R.xml.pref_about);

            // Bind the summaries of EditText/List/Dialog/Ringtone preferences
            // to their values. When their values change, their summaries are
            // updated to reflect the new value, per the Android Design
            // guidelines.
            bindPreferenceSummaryToValue(findPreference("pref_about"));
        }
    }

    public static class PreferencesDto {
        private Boolean serviceActivated = false;
        private Boolean batterySaver = true;
        private Integer lightAutoOffMinutes = 5;
        private Boolean vibrate = true;
        private SensibilityLevel sensibilityLevel = SensibilityLevel.MEDIUM;

        //Getters & Setters
        public Boolean getServiceActivated() {
            return serviceActivated;
        }

        public void setServiceActivated(Boolean serviceActivated) {
            this.serviceActivated = serviceActivated;
        }

        public Boolean getBatterySaver() {
            return batterySaver;
        }

        public void setBatterySaver(Boolean batterySaver) {
            this.batterySaver = batterySaver;
        }

        public Integer getLightAutoOffMinutes() {
            return lightAutoOffMinutes;
        }

        public void setLightAutoOffMinutes(Integer lightAutoOffMinutes) {
            this.lightAutoOffMinutes = lightAutoOffMinutes;
        }

        public Boolean getVibrate() {
            return vibrate;
        }

        public void setVibrate(Boolean vibrate) {
            this.vibrate = vibrate;
        }

        public SensibilityLevel getSensibilityLevel() {
            return sensibilityLevel;
        }

        public void setSensibilityLevel(SensibilityLevel sensibilityLevel) {
            this.sensibilityLevel = sensibilityLevel;
        }

        public Integer getSensibilityLevelAsInteger() {
            Integer result = 0;
            switch (this.sensibilityLevel) {
                case VERY_LOW:
                    result = 1;
                    break;
                case LOW:
                    result = 2;
                    break;
                case MEDIUM:
                    result = 3;
                    break;
                case HIGH:
                    result = 4;
                    break;
            }
            return result;
        }

        public void setSensibilityLevelAsInteger(Integer sensibilityLevel) {
            switch (sensibilityLevel) {
                case 1:
                    this.sensibilityLevel = SensibilityLevel.VERY_LOW;
                    break;
                case 2:
                    this.sensibilityLevel = SensibilityLevel.LOW;
                    break;
                case 3:
                    this.sensibilityLevel = SensibilityLevel.MEDIUM;
                    break;
                case 4:
                    this.sensibilityLevel = SensibilityLevel.HIGH;
                    break;
            }
        }

public enum SensibilityLevel  {VERY_LOW , LOW, MEDIUM, HIGH }
    }

}

package com.handysparksoft.shakelamp;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.hardware.Camera;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.hardware.camera2.CameraManager;
import android.os.PowerManager;
import android.os.Vibrator;
import android.util.Log;
import android.widget.ImageButton;

import java.io.Serializable;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by davasens on 3/23/2015.
 */
public class ShakeLamp extends BroadcastReceiver implements Serializable {
    private static final String LOG_TAG = ShakeLamp.class.getName();
    private static final float G_FORCE_SHAKE_THRESHOLD_LIGHT_ON_DEFAULT = 1.3F; //1.5F
    private static final float G_FORCE_SHAKE_THRESHOLD_LIGHT_OFF_DEFAULT = 1.2F;//1.0F
    private static final long INTERVAL_DELAY_CHECK_SHAKE = 140;   //Milliseconds interval to check for shakes
    private long CURRENT_INTERVAL_DELAY_CHECK_SHAKE = INTERVAL_DELAY_CHECK_SHAKE;
    private static final int DELAY_TO_ON = 5;   //Shake counter to LIGHT ON
    private static final int DELAY_TO_OFF = 4;  //Shake counter to LIGHT OFF
    private static final long TIMER_PAUSE_DELAY = 1100L; //Wait Time after toggle
    private static final int MAX_ACTIVE_MINUTES_DEFAULT = 5; //Max active time for lamp (5 minutes)
    public static  Boolean running = false;
    private final double calibration = SensorManager.STANDARD_GRAVITY;
    //Preferences
    SettingsActivity.PreferencesDto preferencesDto;
    SharedPreferences.OnSharedPreferenceChangeListener prefsListener;
    Boolean firstTime = true;
    private MainActivity mainActivity = null;
    private boolean alwaysListen = true;
    private float currentAcceleration = 0;
    private float maxAcceleration = 0;
    private final SensorEventListener sensorEventListener  = new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent event) {
            double x = event.values[0];
            double y = event.values[1];
            double z = event.values[2];

            double a = Math.round(Math.sqrt(Math.pow(x, 2) + Math.pow(y, 2) + Math.pow(z, 2)));
            currentAcceleration = Math.abs((float) (a - calibration)); //G

            if (currentAcceleration > maxAcceleration) {
                maxAcceleration = currentAcceleration;
            }
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {

        }
    };
    private Timer timer = null;
    private long shakeCount = 0;
    private long noShakeCount = 0;
    private Context context;
    private SensorManager sensorManager;
    private Vibrator vibrator;
    private AlarmManager alarmManager;
    private PowerManager.WakeLock wakeLock;
    //Torch
    private ImageButton btnSwitch;
    private android.hardware.Camera camera;
    private boolean isFlashOn = false;
    private boolean hasFlash = true;
    private android.hardware.Camera.Parameters params;

    public static Boolean getRunning() {
        return running;
    }

    public static void setRunning(Boolean running) {
        ShakeService.running = running;
    }

    public void init(Context context) {
        this.context = context;
        //final Context contextForPrefs = context;

        //Get preferences
        if (prefsListener == null) {
            prefsListener = new SharedPreferences.OnSharedPreferenceChangeListener() {
                @Override
                public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
                    //setPreferencesDto(SettingsActivity.getShakeLampPreferences(contextForPrefs));
                    reloadPreferences();
                }
            };
            SettingsActivity.getPrefs(context).registerOnSharedPreferenceChangeListener(prefsListener);
        }
        reloadPreferences();
        //setPreferencesDto(SettingsActivity.getShakeLampPreferences(context));

        //Init detection
        initDetection();
    }

    private void reloadPreferences() {
        SettingsActivity.PreferencesDto previousPreferencesDto = getPreferencesDto();
        setPreferencesDto(SettingsActivity.getShakeLampPreferences(context));

        if (!firstTime && mainActivity != null && mainActivity.getShakeService() != null) {
            if (!preferencesDto.getServiceActivated()) {
                //ShakeService
                if (mainActivity.getShakeService().getRunning()) {
                    mainActivity.getShakeService().stopShakeService();
                }
            }else {
                if (!mainActivity.getShakeService().getRunning()) {
                    mainActivity.getShakeService().startService(new Intent(mainActivity, ShakeService.class));
                }
            }
            //SettingsActivity.getPrefs(context).edit().putBoolean(Constants.PREF_SERVICE_ACTIVATED, mainActivity.getShakeService().getRunning()).commit();
        }

        if (firstTime || previousPreferencesDto == null || !previousPreferencesDto.getBatterySaver().equals(getPreferencesDto().getBatterySaver())) {
            if (!preferencesDto.getBatterySaver()) {
                Log.w("New PARTIAL_WAKE_LOCK", LOG_TAG);

                PowerManager pm = (PowerManager)context.getSystemService(Context.POWER_SERVICE);
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, LOG_TAG);
                wakeLock.acquire();

                Log.w(LOG_TAG, "wakelock acquired");
            }else if (wakeLock != null) {
                //Release
                wakeLock.release();
                Log.w(LOG_TAG, "wakelock released");
            }
        }

        if (previousPreferencesDto != null && !previousPreferencesDto.getSensibilityLevel().equals(getPreferencesDto().getSensibilityLevel())) {
            Log.w(LOG_TAG, "Sensibility mode changed!");
            startTimer(0L, INTERVAL_DELAY_CHECK_SHAKE);
        }
        firstTime = false;
    }

    public void initDetection() {
        vibrator = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
        alarmManager = (AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
        sensorManager =  (SensorManager)context.getSystemService(Context.SENSOR_SERVICE);
        Sensor accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        sensorManager.registerListener(sensorEventListener, accelerometer, SensorManager.SENSOR_DELAY_FASTEST);

        startTimer(0L, INTERVAL_DELAY_CHECK_SHAKE);
    }

    private void startTimer(Long delay, final Long period) {
        if (timer != null) {
            timer.cancel();
            timer = null;
        }
        if (timer == null) {
            timer = new Timer("gForceUpdate");
            //int INTERVAL_DELAY_CHECK_SHAKE

            float thresholdToApply = isFlashOn ? G_FORCE_SHAKE_THRESHOLD_LIGHT_OFF_DEFAULT : G_FORCE_SHAKE_THRESHOLD_LIGHT_ON_DEFAULT;
            int delayToApply = isFlashOn ? DELAY_TO_OFF : DELAY_TO_ON;

            //Adjust sensibility
            SettingsActivity.PreferencesDto.SensibilityLevel sensibilityLevel = preferencesDto.getSensibilityLevel();
            if (sensibilityLevel != null) {
                switch (sensibilityLevel) {
                    case VERY_LOW:
                        thresholdToApply = thresholdToApply * 1.3f;
                        delayToApply = delayToApply + 1;
                        break;
                    case LOW:
                        thresholdToApply = thresholdToApply * 1f; //Equal
                        delayToApply = delayToApply + 0;
                        break;
                    case MEDIUM:
                        thresholdToApply = thresholdToApply * 0.7f;
                        delayToApply = delayToApply - 1;
                        break;
                    case HIGH:
                        thresholdToApply = thresholdToApply * 0.4f;
                        delayToApply = delayToApply - 1;
                        break;
                }
            }

            final float finalThresholdToApply = thresholdToApply;
            final float finalDelayToApply = delayToApply;


            timer.scheduleAtFixedRate(new TimerTask() {
                @Override
                public void run() {


                    if (getGForceCurrentAcceleration() > finalThresholdToApply) {
                        Log.w(LOG_TAG, String.valueOf(getGForceCurrentAcceleration()));
                        shakeCount++;
                        noShakeCount = 0;


                        if (shakeCount > finalDelayToApply) {
                            shakeHandler();
                            shakeCount = 0;
                            startTimer(TIMER_PAUSE_DELAY, period);

                        }else if (CURRENT_INTERVAL_DELAY_CHECK_SHAKE != INTERVAL_DELAY_CHECK_SHAKE) {
                            CURRENT_INTERVAL_DELAY_CHECK_SHAKE = INTERVAL_DELAY_CHECK_SHAKE;
                            startTimer(0L, CURRENT_INTERVAL_DELAY_CHECK_SHAKE);
                            Log.w(LOG_TAG, "Shake detection frequency fixed to "+ CURRENT_INTERVAL_DELAY_CHECK_SHAKE +" ms");
                        }
                    } else {
                        shakeCount = 0;
                        noShakeCount++;

                        if (noShakeCount == 2 * 300) { //2 min
                            CURRENT_INTERVAL_DELAY_CHECK_SHAKE = period * 10; //2 seg aprox
                            startTimer(0L, CURRENT_INTERVAL_DELAY_CHECK_SHAKE);
                            Log.w(LOG_TAG, "Shake detection frequency fixed to "+ CURRENT_INTERVAL_DELAY_CHECK_SHAKE +" ms");
                        }
                    }
                }
            }, delay, period);
        }
    }

    public void stopTimerIfBatterySaver() {
        if (getPreferencesDto().getBatterySaver()) {
            if (timer != null) {
                timer.cancel();
                timer = null;
                Log.w(LOG_TAG, "Timer stopped cause SCREEN is OFF and Battery Saver enabled");
            }
        }
    }

    public void restartTimerIfBatterySaver() {
        if (getPreferencesDto().getBatterySaver()) {
            startTimer(0L, INTERVAL_DELAY_CHECK_SHAKE);
            Log.w(LOG_TAG, "Timer stopped cause SCREEN is ON and Battery Saver enabled");
        }
    }

    private void shakeHandler() {
        //Set alarm to control active time limit
        if (isFlashOn) {
            cancelMaxActiveTimeAlarm();
            mainActivity.showNotification(false);
        }else {
            setMaxActiveTimeAlarm();
            mainActivity.showNotification(true);
        }

        //Toggle Lamp
        toggleLamp();
    }

    public void toggleLamp() {
        if (isFlashOn) {
            //Change background
            if (mainActivity != null) {
                mainActivity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        mainActivity.lightOffBackground();
                    }
                });
            }

            //Vibration
            if (preferencesDto.getVibrate()) {
                vibrate(1, 100);
            }

            // turn off flash
            turnOffFlash();
            Log.w(LOG_TAG, "Toggle Lamp off");

        } else {
            //Change background
            if (mainActivity != null) {
                mainActivity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        mainActivity.lightOnBackground();
                    }
                });
            }

            //Vibration
            if (preferencesDto.getVibrate()) {
                vibrate(2, 100);
            }

            // turn on flash
            turnOnFlash();

            Log.w(LOG_TAG, "Toggle Lamp ON");
        }
    }

    /*
    * Turning On flash
    */
    private CameraManager cameraManager;
    private String cameraID;
    private void turnOnFlash() {
        cameraManager = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
        if (!isFlashOn) {
            try {
                cameraID = cameraManager.getCameraIdList()[0];
                cameraManager.setTorchMode(cameraID, true);
//                params = camera.getParameters();
//                params.setFlashMode(Camera.Parameters.FLASH_MODE_TORCH);
//                camera.setParameters(params);
//                camera.startPreview();

                isFlashOn = true;
            }catch (Exception e) {
                Log.w(LOG_TAG, e.getMessage());
            }

            // changing button/switch image
            //toggleButtonImage();

            Log.w(LOG_TAG, "Lamp ON");
        }
    }

    /*
    * Turning Off flash
    */
    public void turnOffFlash() {
        if (isFlashOn) {
//            if (camera == null || params == null) {
//                return;
//            }
            try {
                cameraManager = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
                cameraID = cameraManager.getCameraIdList()[0];
                cameraManager.setTorchMode(cameraID, false);
//            params = camera.getParameters();
//            params.setFlashMode(android.hardware.Camera.Parameters.FLASH_MODE_OFF);
//            camera.setParameters(params);
//            camera.stopPreview();
//            camera.release();
                isFlashOn = false;
            } catch (Exception e) {
                e.printStackTrace();
            }

            // changing button/switch image
            //toggleButtonImage();

            Log.w(LOG_TAG, "Lamp OFF");
        }
    }

    public void checkLamp(Context context, final Activity activityCaller) {
        this.mainActivity = (MainActivity)activityCaller;

        hasFlash = context.getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH);

        if (!hasFlash) {
            // device doesn't support flash. Show alert message and close the application
            AlertDialog alert = new AlertDialog.Builder(activityCaller).create();
            alert.setTitle(context.getString(R.string.shake_lamp_msg_error));
            alert.setMessage(context.getString(R.string.shake_lamp_msg_not_flash_support));
            alert.setButton("OK", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    // closing the application
                    //activityCaller.finish();
                }
            });
            alert.show();
            return;
        }
    }

    private void vibrate(int repetitions, long delayMs) {
        long pauseMs = 300;
        for (int i=0;i<repetitions;i++) {
            vibrator.vibrate(delayMs);
            try {
                Thread.sleep(pauseMs);
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private PendingIntent getPendingIntentAlarmMaxActiveTime() {
        Intent intentReceiver = new Intent(Constants.ACTION_MAX_ACTIVE_TIME_ALARM);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this.context, 0, intentReceiver, 0);
        return pendingIntent;
    }

    private Integer getMinutesAutoLightOff() {
        int result = MAX_ACTIVE_MINUTES_DEFAULT;
        if (preferencesDto.getLightAutoOffMinutes() != null) {
            result = preferencesDto.getLightAutoOffMinutes();
        }
        return result;
    }

    //Alarm receiver to turn off lamp if active time exceeds limit
    /*public static class OnMaxActiveTimeReceiver extends BroadcastReceiver {

        //private static final String LOG_TAG = ShakeLamp.class.getName();

        @Override
        public void onReceive(Context context, Intent intent) {
            Log.w(LOG_TAG, "Max time alarm triggered");
            //turnOffFlash();
        }
    }*/

    private void setMaxActiveTimeAlarm() {
        if (getMinutesAutoLightOff() > 0) {
            int alarmType = AlarmManager.RTC_WAKEUP;
            long timeFromNow = System.currentTimeMillis() + (getMinutesAutoLightOff() * 1000 * 60); //Convert to milliseconds
            alarmManager.set(alarmType, timeFromNow, getPendingIntentAlarmMaxActiveTime());
            Log.w(LOG_TAG, "MaxActiveTimeAlarm setted");
        }
    }

    //Getters & Setters

    private void cancelMaxActiveTimeAlarm() {
        try {
            alarmManager.cancel(getPendingIntentAlarmMaxActiveTime());
            Log.w(LOG_TAG, "MaxActiveTimeAlarm canceled");
        }catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.w(LOG_TAG, "Max time alarm triggered");
        //FIXME: Codigo muy feo
        ShakeService.getShakeLampInstance().turnOffFlash();
    }

    public float getGForceMaxAcceleration() {
        return maxAcceleration / SensorManager.STANDARD_GRAVITY;
    }

    public float getGForceCurrentAcceleration() {
        return currentAcceleration /SensorManager.STANDARD_GRAVITY;
    }

    public SettingsActivity.PreferencesDto getPreferencesDto() {
        return preferencesDto;
    }

    public void setPreferencesDto(SettingsActivity.PreferencesDto preferencesDto) {
        this.preferencesDto = preferencesDto;
    }
}

package com.handysparksoft.shakelamp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class ScreenStateReceiver extends BroadcastReceiver {

    private static final String LOG_TAG = ScreenStateReceiver.class.getName();

    private ShakeLamp shakeLamp;

    public ScreenStateReceiver() {
    }

    public static String getLogTag() {
        return LOG_TAG;
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        if ("android.intent.action.SCREEN_ON".equals(intent.getAction())) {
            shakeLamp.restartTimerIfBatterySaver();
            Log.w(LOG_TAG, "Screen state ON");
        }
        if ("android.intent.action.SCREEN_OFF".equals(intent.getAction())) {
            shakeLamp.stopTimerIfBatterySaver();
            Log.w(LOG_TAG, "Screen state OFF");
        }
    }

    public ShakeLamp getShakeLamp() {
        return shakeLamp;
    }

    public void setShakeLamp(ShakeLamp shakeLamp) {
        this.shakeLamp = shakeLamp;
    }
}

package com.handysparksoft.shakelamp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class BootUpCompletedReceiver extends BroadcastReceiver {

    private static final String LOG_TAG = BootUpCompletedReceiver.class.getName();

    public BootUpCompletedReceiver() {
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        if ("android.intent.action.BOOT_COMPLETED".equals(intent.getAction())) {
            Intent i = new Intent(context, ShakeService.class);
            context.startService(i);
        }
        Log.w(LOG_TAG, "BootUpCompleted received");
    }
}

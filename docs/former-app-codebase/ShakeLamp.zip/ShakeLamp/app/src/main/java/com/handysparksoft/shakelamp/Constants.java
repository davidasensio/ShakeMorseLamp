package com.handysparksoft.shakelamp;

/**
 * Created by davasens on 3/25/2015.
 */
public interface Constants {
    public static final String ACTION_MAX_ACTIVE_TIME_ALARM = "com.handysparksoft.shakelamp.ACTION_MAX_ACTIVE_TIME_ALARM";

    public static final String ACTION_SHARE_APP = "com.handysparksoft.shakelamp.ACTION_SHARE_APP";
    public static final String ACTION_ABOUT = "com.handysparksoft.shakelamp.ACTION_ABOUT";


    //Preferences
    public static final String PREF_SERVICE_ACTIVATED = "pref_service_activated";
    public static final String PREF_BATTERY_CARE = "pref_battery_care";
    public static final String PREF_LIGHT_AUTO_OFF = "pref_max_time_light_on";
    public static final String PREF_VIBRATE = "pref_vibrate";
    public static final String PREF_SENSIBILITY = "pref_sensibility";
}

package com.handysparksoft.shakelamp;

import android.app.Activity;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdView;

import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by davasens on 4/17/2015.
 */
public class AdCustomListener extends AdListener {

    private static final Long BANNER_HIDE_TIME = 1 * 60 * 60 * 1000L; //Ms that banner will be hided if user clicks it (1hour)
    private static final String LOG_TAG = AdCustomListener.class.getName();
    private Activity mainActivity = null;
    private AdView adView = null;
    private TextView txtBanner = null;
    private Timer timerVisibility = null;

    public AdCustomListener(Activity activity, AdView adView, TextView textView) {
        this.mainActivity = activity;
        this.adView = adView;
        this.txtBanner = textView;
        this.adView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideBanner();
            }
        });

    }

    @Override
    public void onAdOpened() {
        super.onAdOpened();
        hideBanner();
    }

    @Override
    public void onAdLoaded() {
        super.onAdLoaded();
        txtBanner.setVisibility(View.VISIBLE);

    }

    private void hideBanner() {
        //Hide Banner
        txtBanner.setVisibility(View.INVISIBLE);
        adView.setVisibility(View.INVISIBLE);
        Log.d(LOG_TAG, "Banner hided");
        //this.adView.destroy();

        //Show after a while
        timerVisibility = new Timer();
        timerVisibility.schedule(new TimerTask() {
            @Override
            public void run() {
                mainActivity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        txtBanner.setVisibility(View.VISIBLE);
                        adView.setVisibility(View.VISIBLE);
                        Log.d(LOG_TAG, "Banner displayed");
                    }
                });
            }
        }, BANNER_HIDE_TIME );
    }
}

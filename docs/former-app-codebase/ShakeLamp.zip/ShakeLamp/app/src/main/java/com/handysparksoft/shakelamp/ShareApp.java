package com.handysparksoft.shakelamp;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;

/**
 * Created by davasens on 3/27/2015.
 */
public class ShareApp extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (Constants.ACTION_SHARE_APP .equals(getIntent().getAction())) {
            Intent emailIntent = new Intent(Intent.ACTION_SEND);
            emailIntent.setType("text/plain");
            emailIntent.putExtra(Intent.EXTRA_TEXT, getString(R.string.share_app_body));
            emailIntent.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.share_app_subject));
            startActivity(emailIntent);
            finish();
        }
        else if (Constants.ACTION_ABOUT.equals(getIntent().getAction())) {
            String version = "";
            try {
                version = this.getPackageManager().getPackageInfo(this.getPackageName(), 0).versionName;
            } catch (PackageManager.NameNotFoundException e) {
                //Nothing
            }
            AlertDialog alert = new AlertDialog.Builder(this).create();
            alert.setTitle(getString(R.string.share_app_information));
            alert.setMessage(getString(R.string.share_app_message1) + version + getString(R.string.share_app_message2));
            alert.setButton("OK", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    finish();
                }
            });
            alert.show();
        }

        super.onCreate(savedInstanceState);
    }
}

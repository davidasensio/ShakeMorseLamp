package com.handysparksoft.shakelamp;

import android.app.Activity;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.preference.PreferenceManager;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.ActionBarActivity;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

import java.util.Timer;
import java.util.TimerTask;

/**
 * Change Log
 * 17-04-2015: V 1 (1.0.0)
 * 17-04-2015: V 2 (1.0.1) Api 22 & Notifications added & AdMob Banner linked
 */
public class MainActivity extends ActionBarActivity {

    private static final String LOG_TAG = MainActivity.class.getName();
    private RelativeLayout mainLayout;

    private TextView txtCurrent;
    private TextView txtMax;
    private ShakeService shakeServiceRef;
    private ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            shakeServiceRef = ((ShakeService.ShakeBinder)service).getService();
            init();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            shakeServiceRef = null;
            stopGUI();
        }
    };
    private Boolean isFlashOn = false;
    private Activity mainActivity = this;
    private Boolean isActivityVisible = false;
    private Timer timerReader = null;
    private AdView adView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtCurrent = (TextView)findViewById(R.id.txtCurrent);
        txtMax = (TextView)findViewById(R.id.txtMax);
        mainLayout = ((RelativeLayout)findViewById(R.id.mainBackground));

        PreferenceManager.setDefaultValues(this, R.xml.pref_general, false);
        PreferenceManager.setDefaultValues(this, R.xml.pref_user, false);

        //Bind service in order to be possible make calls Service methods
        //if (!ShakeService.getRunning()) {
            //Init service
            startService(new Intent(this, ShakeService.class));
       // }

        Toast toast = Toast.makeText(this, getString(R.string.shakeSecondsMsg),Toast.LENGTH_LONG);
        toast.setGravity(Gravity.TOP,0,250);
        toast.show();

        //Publicidad
        adView = (AdView) findViewById(R.id.adView);
        //AdRequest adRequest = new AdRequest.Builder().addTestDevice(AdRequest.DEVICE_ID_EMULATOR).addTestDevice("8DBB3294399A59F966A4B5694A8563CF").build();
        AdRequest adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);
        TextView txtBanner = (TextView) findViewById(R.id.txtBanner);
        adView.setAdListener(new AdCustomListener(this, adView,txtBanner ));
    }


    @Override
    protected void onResume() {
        isActivityVisible = true;
        //Bind service
        Intent bindIntent = new Intent(MainActivity.this, ShakeService.class);
        bindService(bindIntent, serviceConnection, BIND_AUTO_CREATE);

        startGUI();
        adView.resume();

        Intent i = getIntent();
        boolean mustTurnOff = i.getBooleanExtra("must_turn_off", false);
        if (mustTurnOff) {
            shakeServiceRef.getShakeLampInstance().turnOffFlash();
            i.removeExtra("must_turn_off");
            showNotification(false);
        }
        super.onResume();
    }

    @Override
    protected void onPause() {
        isActivityVisible = false;
        //Unbind service
        unbindService(serviceConnection);

        stopGUI();
        adView.pause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void lightOnBackground() {
        findViewById(R.id.mainBackground).setBackgroundResource(R.drawable.bulb_green_on);
        isFlashOn = true;
    }

    public void lightOffBackground() {
        findViewById(R.id.mainBackground).setBackgroundResource(R.drawable.bulb_green_off);
        isFlashOn = false;
    }

    public void showNotification(Boolean show) {
        NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (show && !isActivityVisible) {
            NotificationCompat.Builder mBuilder =
                    new NotificationCompat.Builder(this)
                            .setSmallIcon(R.mipmap.ic_launcher)
                            .setContentTitle(getString(R.string.notificationTitle))
                            .setContentText(getString(R.string.notificationText));

            Intent notificationIntent = new Intent(this, MainActivity.class);
            notificationIntent.putExtra("must_turn_off", true);
            PendingIntent contentIntent = PendingIntent.getActivity(this, 0, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);
            mBuilder.setContentIntent(contentIntent);

            // mId allows you to update the notification later on.
            mNotificationManager.notify(1, mBuilder.build());
        }else if (!show) {
            mNotificationManager.cancel(1);
        }

    }

    @Override
    protected void onStop() {
        //unbindService(serviceConnection);
        super.onStop();
    }

    private void init() {
        shakeServiceRef.getShakeLampInstance().checkLamp(getApplicationContext(), mainActivity);
        startGUI();

        mainLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shakeServiceRef.getShakeLampInstance().toggleLamp();
            }
        });

        /*
        btnPress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shakeServiceRef.getShakeLampInstance().toggleLamp();
            }
        });*/
    }

    private void startGUI() {
        if (shakeServiceRef != null && timerReader == null) {
            timerReader = new Timer();
            timerReader.scheduleAtFixedRate(new TimerTask() {
                @Override
                public void run() {
                    updateGUI();
                }
            }, 0, 100);
        }

        if (isFlashOn) {
            lightOnBackground();
        }else {
            lightOffBackground();
        }
    }

    private void stopGUI() {
        if (timerReader != null) {
            timerReader.cancel();
            timerReader = null;
        }
    }

    private void updateGUI() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                String current = shakeServiceRef.getShakeLampInstance().getGForceCurrentAcceleration() + " G";
                String max = shakeServiceRef.getShakeLampInstance().getGForceMaxAcceleration() + " G";
                txtCurrent.setText(String.valueOf(current));
                txtCurrent.invalidate();
                txtMax.setText(String.valueOf(max));
                txtMax.invalidate();
            }
        });
    }

    public ShakeService getShakeService() {
        return shakeServiceRef;
    }
}
